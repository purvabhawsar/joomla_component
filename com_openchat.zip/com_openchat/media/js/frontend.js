 

 // alert("hello");
 // var JQ= jQuery.noConflict();
jQuery(document).ready(function(){
	jQuery(document).on('click','#btn',function(){
		
		var msg = jQuery("#msg").val().trim();

    // alert(msg);

       var param = {};
       param.option = 'com_openchat';
       param.task = 'saveChatViaAjax';
       param.msg = msg;
        // alert(param.msg);
       jQuery.post('index.php',param,function(res){
       
       
       // var stringified = JSON.eval(res);
        //var result = JSON.parse(res);
       // alert(result.msg);
       
       
       	 // var result = JSON.parse(res);
         alert(res);
        
       	// if (result.status)
        //  {
       	//    jQuery('#msg').val('');
        //    }
        // else{
       	// 	alert(result.msg); 
       	// }

        var chatDetail=res.chatDetail;
        alert(chatDetail);
        var chatHTML='';
        chatHTML+='<li id="'+chatDetail.id+'">';
        chatHTML+='<span id="user">'+chatDetail.msg+'</span>';
        chatHTML+='</li>';
        console.log(chatHTML);
     
        });
	});
 });

