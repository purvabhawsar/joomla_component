<?php 

defined('_JEXEC')or die('Restricted access');

error_reporting('E_ALL');
ini_set(display_errors, 1);

/**
 * 
 */
//echo "purva";
class OpenchatController extends JControllerLegacy
{
     function display()
      {
            
        $doc = JFactory::getDocument();

        JHtml::_('jquery.framework');
        //$doc->addStyleSheet(JURI::root().'/media/com_openchat/css/frontend.css');
         
         // $doc->addScript(JURI::root().'media/com_openchat/js/jquery-3.6.0/jquery.min.js');
        $doc->addScript(JURI::root().'media/com_openchat/js/frontend.js');

       


        ?>
          
          <div>
              <label>message</label>
              <input type="text" name="msg" id="msg">
              <input type="button" name="btn" id="btn" value="send">
          </div>
   <?php 
 }

 function saveChatViaAjax()
 {

      
      $app = JFactory::getApplication();
      $msg = JRequest::getString('msg');
      $user_id = JFactory::getUser()->id;
      
      // echo $msg;
      // echo $user_id;

      // die();
   
      // if ($msg == '')
      //  {
      //    $res['msg']="please enter message";
      //    $res['status'] = false;
      //   // $this->setMessage("a message");
      //    echo json_encode($res);
      //    exit();
      // }
      // if ($user_id == 0)
      //  {
      //    $res['msg']="please login your account";
      //    $res['status'] = false;
      //    echo json_encode($res);
      //    exit();
      // }
      // if($this->saveChat($user_id,$msg))
      //  {
      //   $res['status'] = true;
      //  }else
      //  {
      //    $res['status'] = false;
      //  }
      //  echo json_encode($res);
      //   //echo $msg.'||'.$user_id;
      //   $app->close();
       $res = array();
        if ($msg == '')
       {
        // $res = array();
        $res['status'] = false;
        $res['msg'] = 'Please enter massage..';
        echo json_encode($res);
        exit();
       }
       if ($user_id == 0)
        {
         // $res = array();
         $res['status'] = false;
         $res['msg'] = 'Please login before chat..';
         echo json_encode($res);
         exit();
        }

      if ($chatId=$this->saveChat($user_id,$msg))
       {
         $chatId;
         $chatDetail = $this->getchatDetailsById($chatId);
        $res['chatDetail'] = $chatDetail;
        $res['status'] = true;
       }else
       {
         $res['status'] = false;
       }
       echo json_encode($res);
        //echo $msg.'||'.$user_id;
        $app->close();
    }
    function saveChat($user_id,$msg)
    {
      // $user_id = (Int)$user_id;
      $db = JFactory::getDbo();
      $query = "INSERT INTO `#__openchat_msg`(`user_id`,`msg`)VALUES('$user_id','$msg')";
      $db->setQuery($query);
      // $db->query();
      if ($db->query())
       {
        return true;
       }else
       {
        return false;
       }
    }

      function getChatDetailsById($id)
      {
         //$id=(INT)$id;
        $db=JFactory::getDBO();
        $query="SELECT c.id,c.msg,u.name from `#__openchat_msg` as c LEFT JOIN `#__users` as u ON c.user_id=u.id WHERE c.id='$id'";
         echo $query;
        $db->setQuery($query);
         return $db->loadObject();


      }
    











     function history()
     {
        echo "history";
     }
     function blocked()
     {
        echo "blocked";
     }
}



?>