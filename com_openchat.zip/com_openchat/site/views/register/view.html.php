<?php 

defined('_JEXEC')or die('Restricted access');

/**
 * 
 */
class OpenchatViewOpenchat extends JViewLegacy
{

	echo "hello";
	
	function display($tpl=null)
	{
	     $this->msg='work done';
	     parent::display($tpl);
	}
}

?>