DROP TABLE IF EXISTS `#__openchat_msg`;
DROP TABLE IF EXISTS `#__openchat_blocked_users`;