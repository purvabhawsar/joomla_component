-- DROP TABLE IF EXISTS '#__regis_posts';
DROP TABLE IF EXISTS `#__regis_posts`;
