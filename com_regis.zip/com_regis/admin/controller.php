<?php 
 defined('_JEXEC')or die();


 
 class RegisterController extends JControllerLegacy
 {
 	
 	
 	function display()
 	{   

        JToolBarHelper::Title("purva component");
 		echo JText::_('display');
 	}
 	function create()
 	{   
        echo "<span class='welcome'>this is create</span>";
          echo "<img src='../media/com_regis/images/img1.png' class='create-submenuicon' height='20px' width='20px'>";
        $doc=JFactory::getDocument();
        $doc->addStyleSheet(JURI::root().'/../media/com_regis/css/backend_style.css');
        $doc->addScript(JURI::root().'/../media/com_regis/js/backend.js');
        JToolBarHelper::Title("create task","new");

        echo JText::_('create');
      

      $db=JFactory::getDBO();
      $query="INSERT INTO `#__regis_posts`(`title`,`body`)VALUES('firstone','This is my first entry')";
      $db->setQuery($query);
      $db->query();



 	}

    function updatepost()
    {

     $doc=JFactory::getDocument();
        $doc->addStyleSheet(JURI::root().'/../media/com_regis/css/backend_style.css');
        $doc->addScript(JURI::root().'/../media/com_regis/js/backend.js');


      $id=JRequest::getInt('id',0);
      if ($id>0)
       {
         $db=JFactory::getDBO();
         $query="UPDATE  `#__regis_posts` SET `title`='update one' WHERE `id`='$id'";
         $db->setQuery($query);
      $db->query();
      echo "<span class='g_update'>your selected id updated</span>";


      }
      else
      {
        echo  "<span class='r_update'>please select id for update</span>";
      }
    }

 	function delete()
 	{

      $doc=JFactory::getDocument();
        $doc->addStyleSheet(JURI::root().'/../media/com_regis/css/backend_style.css');
        $doc->addScript(JURI::root().'/../media/com_regis/js/backend.js');

        JToolBarHelper::Title("Delete the task");
 		echo JText::_('delete');
        $id=JRequest::getInt('id',0);
      if ($id>0)
       {
         $db=JFactory::getDBO();
         $query="DELETE FROM `#__regis_posts` WHERE `id`='$id' LIMIT 1";
         $db->setQuery($query);
      $db->query();
      echo "<span class='gdelete'>your selected id deleted</span>";

      }
      else
      {
        echo "<span class='rdelete'>Please select id</span>";
      }
 	}
     function help()
    {

       $doc=JFactory::getDocument();
        $doc->addStyleSheet(JURI::root().'/../media/com_regis/css/backend_style.css');
        $doc->addScript(JURI::root().'/../media/com_regis/js/backend.js');

        echo "<img src='../media/com_regis/images/img2.png' >";
        $doc=JFactory::getDocument();
        JToolBarHelper::Title("Help","help");
        echo JText::_('help');
    }
    function listtask()
    { 
        echo "<img src='../media/com_regis/images/img3.png' >";
        $doc=JFactory::getDocument();
        JToolBarHelper::Title("List of Task","list");
        echo JText::_('listtask');

        $db=JFactory::getDBO();
        $query="SELECT * FROM `#__regis_posts`";
        $db->setQuery($query);
        $rows=$db->loadObjectList();
        for ($i=0; $i < count($rows) ; $i++)
         { 
            $row=$rows[$i];
            $id=$row->id;
            $title=$row->title;
            $body=$row->body;
            echo $id;
            echo $title;

        }

    }
 }


?>