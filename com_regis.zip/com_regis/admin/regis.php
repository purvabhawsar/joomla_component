<?php 

defined('_JEXEC')or die('Restricted access');
//echo "hello";
//jimport('joomla.application.component.controller');



$controller=JControllerLegacy::getInstance('Register');
$input= JFactory::getApplication()->input;

$controller->execute($input->getCmd('task'));
$controller->redirect();

?>