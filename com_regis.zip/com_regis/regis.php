<?php 

defined('_JEXEC')or die('Restricted access');
 //use Joomla\Utilities\ArrayHelper;
echo "hello";




$controller=JControllerLegacy::getInstance('Register');
$input= JFactory::getApplication()->input;

$controller->execute($input->getCmd('task'));
$controller->redirect();






?>