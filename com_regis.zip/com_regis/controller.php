<?php 

defined('_JEXEC')or die('Restricted access');

/**
 * 
 */
class RegisterController extends JControllerLegacy
{
	
}



?>