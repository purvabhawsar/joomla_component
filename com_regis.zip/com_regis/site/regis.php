<?php 

defined('_JEXEC')or die('Restricted access');
// echo "hello";



// $controller = JControllerLegacy::getInstance('Register');
// $input = JFactory::getApplication()->input;

// $controller->execute($input->getCmd('task'));
// $controller->redirect();

$controller=JControllerLegacy::getInstance('Register');
$input = JFactory::getApplication()->input;
$controller->execute($input->getCmd('task'));
$controller->redirect();







?>