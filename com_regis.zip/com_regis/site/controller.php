<?php 

defined('_JEXEC')or die('Restricted access');

/**
 * 
 */
class RegisterController extends JControllerLegacy
{

    function display()
    {
        // echo "<span class='welcome'>this is display</span>";
      echo JText::_('site display');
      // $doc=JFactory::getDocument();
      // $doc->addStyleSheet(JURI::root().'/../media/com_regis/css/frontend_style.css');
      // $doc->addScript(JURI::root().'/../media/com_regis/js/frontend.js');
    }
	
    // function create()
    // {
    //     echo "<span class='welcome'>this is display</span>";
    //    echo JText::_('create');
    //     $doc=JFactory::getDocument();
    //   $doc->addStyleSheet(JURI::root().'/../media/com_regis/css/frontend_style.css');
    //   $doc->addScript(JURI::root().'/../media/com_regis/js/frontend.js');
    // }

     

     function create()
     {
        $doc = JFactory::getDocument();
        $doc->addStyleSheet(JURI::root().'media/com_regis/css/frontend.css');
        $doc->addScript(JURI::root().'media/com_regis/js/frontend.js');
        echo '<div id="purva">do you want create some task</div>';
    }
          // echo "<img src='../media/com_regis/images/img1.png' class='create-submenuicon' height='20px' width='20px'>";
       
        // JToolBarHelper::Title("create task","new");

        // echo JText::_('create');
   

    function delete()
    {
       echo JText::_('delete');
    }
    function help()
    {
       echo JText::_('help');
    }
    function listtask()
    {
       echo JText::_('task');
    }
}



?>