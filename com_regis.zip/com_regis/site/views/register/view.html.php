<?php 

defined('_JEXEC')or die('Restricted access');

/**
 * 
 */
class RegisterViewRegister extends JViewLegacy
{
	
	function display($tpl=null)
	{
	     $this->msg='work done';
	     parent::display($tpl);
	}
}

?>