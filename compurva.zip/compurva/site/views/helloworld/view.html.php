<?php
/**
 * @package     Joomla.Administrator
 * @subpackage  com_helloworld
 *
 * @copyright   Copyright (C) 2005 - 2018 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

// No direct access to this file
defined('_JEXEC') or die('Restricted access');

/**
 * HTML View class for the HelloWorld Component
 *
 * @since  0.0.1
 */
class HelloWorldViewHelloWorld extends JViewLegacy
{
	/**
	 * Display the Hello World view
	 *
	 * @param   string  $tpl  The name of the template file to parse; automatically searches through the template paths.
	 *
	 * @return  void
	 */
	function display($tpl = null)
	{
		// Assign data to the view
		$this->msg = '<div class="col-lg-12">
<form role="form" method="POST" style="margin-top: 2.7em;" action="">
<div class="row">
<div class="form-group col-lg-4">
<label for="input1">Name</label>
<input type="text" name="contact_name" class="form-control" id="input1">
</div>
<div class="form-group col-lg-4">
<label for="input2">Mail</label>
<input type="email" name="contact_email" class="form-control" id="input2">
</div>
<div class="form-group col-lg-4">
<label for="input3">Phone</label>
<input type="phone" name="contact_phone" class="form-control" id="input3">
</div>
<div class="form-group col-lg-4">
<label for="input1">Dropdown</label>
<select class="form-control" name="bud">
                            <option value="a">parterowy</option>
                            <option value="b">piętrowy</option>
                            <option value="c">bliźniak</option>
                            <option value="c">mieszkalny</option>
                            <option value="c">niemieszkalny</option>
                        </select>
                    </div>
                    <div class="form-group col-lg-4">
                        <label for="input2">Size</label>
                        <input type="email" name="contact_email" class="form-control" id="input2">
                    </div>
                    <div class="form-group col-lg-4">
                        <label for="input3">Garage</label>
                        <select class="form-control" name="garaz">
                            <option value="a">wolnostojący</option>
                            <option value="b">w budynku</option>
                            <option value="c">jednostanowiskowy</option>
                            <option value="c">wielostanowiskowy</option>
                        </select>
                    </div>
                    <div class="clearfix"></div>
                    <div class="form-group col-lg-12">
                        <label for="input4">Msg</label>
                        <textarea name="contact_message" class="form-control" rows="6"id="input4"></textarea>
                    </div>
                    <div class="form-group col-lg-12">
                        <input type="hidden" name="save" value="contact">
                        <button type="submit" class="btn btn-default">Send</button>
                    </div>
                </div>
            </form>

        </div>';

		// Display the view
		parent::display($tpl);
	}
}