<?php
  

   // No direct access
   defined('_JEXEC') or die;

 

   echo "<h2>I am purva bhawsar </h2>";
   
?>