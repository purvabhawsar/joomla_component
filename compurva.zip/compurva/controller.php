<?php 
 
class HelloWorldController extends JControllerLegacy
{
}

?>