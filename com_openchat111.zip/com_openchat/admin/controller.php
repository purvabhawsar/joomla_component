<?php 

defined('_JEXEC')or die('Restricted access');

/**
 * 
 */
class OpenchatController extends JControllerLegacy
{
    function display()
    {   

        JToolBarHelper::Title("purva new chat");
        echo JText::_('chat');
    }

    function history()
    {
       JToolBarHelper::Title("History");
        echo JText::_('History');
    }

     function blocked()
     {
        JToolBarHelper::Title("Blocked Users");
        echo JText::_('Blocked');
     }
	
}



?>