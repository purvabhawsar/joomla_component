<?php 

defined('_JEXEC')or die('Restricted access');

/**
 * 
 */
//echo "purva";
class OpenchatController extends JControllerLegacy
{
	   function display()
      {?>
          echo "this is site";
          <div>
              <label>message</label>
              <input type="text" name="msg">
          </div>
   <?php }

     function history()
     {
        echo "history";
     }
     function blocked()
     {
        echo "blocked";
     }
}



?>